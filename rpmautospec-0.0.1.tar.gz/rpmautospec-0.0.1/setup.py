#!/usr/bin/env python

from distutils.core import setup

setup(name='rpmautospec',
      version='0.0.1',
      description='The rpmautospec tool',
      author='Nils Philipsen',
      author_email='nphilip@redhat.com',
      url='https://pagure.io/fedora-infra/rpmautospec/',
      packages=['rpmautospec'],
      scripts = ['rpmautospec.py']
     )
