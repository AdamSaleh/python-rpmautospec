#!/usr/bin/env python

from rpmautospec.cli import main


main()
